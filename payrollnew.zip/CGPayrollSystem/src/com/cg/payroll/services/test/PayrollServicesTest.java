package com.cg.payroll.services.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUTIL;

public class PayrollServicesTest {
	private static PayrollServices services ;
@BeforeClass
	public static void setUpTestEnv() {
	PayrollServices	services=new PayrollServicesImpl();
	}
@Before
public void setUpTestData()
{
		Associate associate1=new Associate(101, 78000, "Javed", "Syed"," IT", "ANALYST", "3214afasf", "jazz10syed@gmail.com", 
				new Salary(35000, 1800, 1800), new BankDetails(456456, "CITI", "CITI00000015"));
		Associate associate2=new Associate(102, 78500, "Apoorva", "Tiwari"," IT", "ANALYST", "879asdsa", "apoorv.tiwari@gmail.com", 
				new Salary(35000, 1800, 1800), new BankDetails(456456, "CITI", "CITI00000015"));
				
		PayrollDBUTIL.associates.put(associate1.getAssociateId(), associate1);
		PayrollDBUTIL.associates.put(associate2.getAssociateId(), associate2);
		
		PayrollDBUTIL.ASSOCIATE_ID_COUNTER=102;
}
@Test(expected=AssociateDetailNotfoundException.class)
public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailNotfoundException {
	Associate actualAssociate=services.getAssociateDetails(10234);
}
@Test
public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailNotfoundException {
	Associate expectedAssociate=new Associate(101, 78000, "Javed", "Syed"," IT", "ANALYST", "3214afasf", "jazz10syed@gmail.com", 
			new Salary(35000, 1800, 1800), new BankDetails(456456, "CITI", "CITI00000015"));
	Associate actualAssociate=services.getAssociateDetails(102);
}
@Test
public void testAcceptAssociateDetailsForValidData() throws AssociateDetailNotfoundException {
	int expectedId=103;
	int actualId=services.acceptAssociateDetails("agfeag", "afs", "jazz1asf@gmail.com", "Trainee", "analyst", "afds3qw4r", 132, 15000, 1500, 1420, 1000, "CITI", "citi500010");
	Assert.assertEquals(expectedId, actualId);
}
@Test(expected=AssociateDetailNotfoundException.class)
public void testCalCulateNetSalaryForInvalidAssociateId() throws AssociateDetailNotfoundException {
	services.calculateNetSalary(1234);
}
@Test
public void testCalCulateNetSalaryForValidAssociateId() throws AssociateDetailNotfoundException {
	int expectedSalary=0;
	int actualSalary=services.calculateNetSalary(102);
	Assert.assertEquals(expectedSalary, actualSalary);
}
@Test
public void testgetAllAssociateDetails() throws AssociateDetailNotfoundException{
	Associate associate1=new Associate(101, 78000, "Javed", "Syed"," IT", "ANALYST", "3214afasf", "jazz10syed@gmail.com", 
			new Salary(35000, 1800, 1800), new BankDetails(456456, "CITI", "CITI00000015"));	
	Associate associate2=new Associate(102, 78500, "Apoorva", "Tiwari"," IT", "ANALYST", "879asdsa", "apoorv.tiwari@gmail.com", 
			new Salary(35000, 1800, 1800), new BankDetails(456456, "CITI", "CITI00000015"));
	ArrayList<Associate>expectedList=new ArrayList<>();
	expectedList.add(associate1);
	expectedList.add(associate2);
	ArrayList<Associate>actualList=(ArrayList<Associate>) services.getAllAssociateDetails();
}
@After
public void tearDownTestData() {
	PayrollDBUTIL.associates.clear();
	PayrollDBUTIL.ASSOCIATE_ID_COUNTER=100;
}
@AfterClass
public static void tearDownTestEnv() {
	services=null;
}}