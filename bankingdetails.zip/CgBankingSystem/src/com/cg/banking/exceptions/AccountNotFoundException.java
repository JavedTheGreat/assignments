package com.cg.banking.exceptions;

public class AccountNotFoundException extends Exception {

}
