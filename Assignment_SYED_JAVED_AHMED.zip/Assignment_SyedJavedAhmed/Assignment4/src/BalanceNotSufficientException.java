public class BalanceNotSufficientException extends Exception 
{
	BalanceNotSufficientException()
	{
		System.out.println("Balance is low! Unable to withdraw!");
	}

}