public class SavingAccount extends Account
{
	final double minBalance = 500;
	
	public SavingAccount(long accNum, double balance, Person accHolder)
	{
		super(accNum,balance,accHolder);
	}
	
	@Override
	public void withdraw(double m) throws BalanceNotSufficientException
	{
		if((balance-m)>minBalance)
			balance = balance - m;
		else
			throw new BalanceNotSufficientException();
	}

}