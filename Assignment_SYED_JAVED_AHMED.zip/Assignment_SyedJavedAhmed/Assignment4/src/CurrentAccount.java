public class CurrentAccount extends Account
{
	double overDraft;
	

	public CurrentAccount(long accNum,double balance,Person accHolder,double overDraft)
	{
		super(accNum,balance,accHolder);
		this.overDraft = overDraft;
	}
	
	@Override
	public void withdraw(double m)throws OverDraftLimitSurpassed
	{
		if((balance-m)>overDraft)
			balance = balance - m;
		else
			throw new OverDraftLimitSurpassed();
	}

}