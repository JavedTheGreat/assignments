public class Account 
{
	long accNum;
	double balance;
	Person accHolder;
	
	

	public Account() 
	{
		
	}

	public Account(long accNum, double balance, Person accHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	void deposit(double d)
	{
		balance+= d;
	}
	
	void withdraw(double w)throws BalanceNotSufficientException, OverDraftLimitSurpassed
	{
		if((balance-w)>500)
			balance-= w;
		else
			throw new BalanceNotSufficientException();
	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance + "]";
	}
}