import java.util.Scanner;

public class StringOperations {
	
	public String copyString(String str)
	{
		return str+str;
	}
	
	public String oddPlaces(String str)
	{
		char strArray[]= str.toCharArray();
		String s2=" ";
		for(int i=0;i<str.length();i++)
		{
			if(i%2==0)
			{
				strArray[i]='#';
			}
			else
			{
				strArray[i]=str.charAt(i);
			}
			
			s2=s2+strArray[i];
		}
		return s2;
	}
	
	public String dupChar(String str)
	{
		return "";
	}
	
	public String oddToUpperCase(String str)
	{
		char strArray[]= str.toCharArray();
		String s2=" ";
		
		for(int i=0;i<str.length();i++)
		{
			if(i%2!=0)
			{
				if(strArray[i]>='A' & strArray[i]<='Z')
				{
				strArray[i]=str.charAt(i);
				}
			}
			else if(strArray[i]>='a' & strArray[i]<='z')
			{
				strArray[i]=(char)(str.charAt(i)-(char)32);
			}
			
			s2=s2+strArray[i];
		}
		return s2;
	}
	
	
	public static void main(String[] args) {
		
		StringOperations obj=new StringOperations();
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter the string: ");
		String str=scan.next();
		
		System.out.println("\nOperations:"
				+ " \n1) Add the String to itself\n2) Replace odd positions with #"
				+ "\n3) Remove duplicate characters in the String\n4) Change odd characters to upper case"
				+ "\n\nEnter Your Choice: ");
		
		int choice=scan.nextInt();
		
		String s2="";
		
		if(choice==1)
		{
			System.out.println(obj.copyString(str));
		}
		
		else if(choice==2)
		{
			System.out.println(obj.oddPlaces(str));
		}
		
		
		else if(choice==4)
		{
			System.out.println(obj.oddToUpperCase(str));
		}
			
		}
	}


