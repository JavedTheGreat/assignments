import java.util.LinkedHashSet;

//public class DublicateChar {
	
//	   
//		DublicateChar (String str) 
//	    { 
//	    	
//	        LinkedHashSet<Character> lhs = new LinkedHashSet<>(); 
//	        for(int i=0;i<str.length();i++) 
//	            lhs.add(str.charAt(i)); 
//	        
//	        for(Character ch : lhs) 
//	            System.out.print(ch); 
//	    } 
//	      
//	    
//	    public static void main(String args[]) 
//	    { 
//	        String str = "jjjaavvvveeedddddd"; 
//	        DublicateChar  r = new DublicateChar ( str); 
//	        r.DublicateChar (str); 
//	    }
//
//			
//		} 
//	}

