package com.cg.person;

public enum PersonGenderEnum {

	Male,Female;
}
