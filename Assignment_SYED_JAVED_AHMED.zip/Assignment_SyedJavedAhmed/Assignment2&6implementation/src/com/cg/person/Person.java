package com.cg.person;

enum Gender{
		M,F;
	}
public class Person {
	String firstName,lastName;
	Gender gender;
	int age;
	double weight;
	public Person() {
		super();
	}
	public Person(String firstName, String lastName, Gender gender, int age, double weight) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public int getAge() {
		return age;
	}
	public double getWeight() {
		return weight;
	}
}
