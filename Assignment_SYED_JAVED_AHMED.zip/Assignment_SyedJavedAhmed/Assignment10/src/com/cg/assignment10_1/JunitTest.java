package com.cg.assignment10_1;
import org.junit.Assert;
import org.junit.Test;


public class JunitTest {
   @Test
   public void testGetFirstName(){
		Person per = new Person("Javed","Syed");
		Assert.assertEquals("Javed",per.getFirstName());
	}
  @Test
   public void testGetLastName(){
		Person per= new Person("Ishan","Yadav");
		Assert.assertEquals("Yadav",per.getLastName());
   }
  
	}
