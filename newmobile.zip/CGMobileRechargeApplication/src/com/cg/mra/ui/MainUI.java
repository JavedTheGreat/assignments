package com.cg.mra.ui;

import java.security.Provider.Service;
import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidMobileNumber;
import com.cg.mra.service.AccountSerive;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	public static void main(String[] args) throws InvalidMobileNumber {
		AccountSerive serivce= new AccountServiceImpl();
		Account account=new Account();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("-------------------Mobile Recharge Application----------------------");
		System.out.println("Menu");
		System.out.println("Select your option "+"\n1.Account Balance Enquire"+"\n2.Recharge Account"+"\n3.Exit");
		int n=sc.nextInt();
		if(n==3)
		{	
			System.out.println("Thank you");
			System.exit(0);
		}
		else if(n==1)
		{
			System.out.println("Please enter your mobile number ");
			String mobileNo=sc.next();
			if(mobileNo.length()>10||mobileNo.length()<10)
					{
						System.out.println("Invalid Mobile Number");
						throw new InvalidMobileNumber();
					}
			else
			{          account= serivce.getAccountDetails(mobileNo);
				
				System.out.println("Your balance is : "+account.getAccountBalance());
			}
	}
		else
		{
			System.out.println("Please Enter Mobile number ");
			String mobileNo = sc.next();
			System.out.println("Enter Recharge amount ");
			int rechargeAmount = sc.nextInt();
			System.out.println("Recharge successful ");
			System.out.println("Your new balance is "+
			serivce.rechargeAccount(mobileNo, rechargeAmount));
			
			
		}
	}

}
